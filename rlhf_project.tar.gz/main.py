def main():
    print("Hello from rlhf-hybrid-capstone!")


if __name__ == "__main__":
    main()
